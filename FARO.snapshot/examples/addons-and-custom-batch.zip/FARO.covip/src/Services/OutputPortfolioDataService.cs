using System;
using System.Linq;
using System.Collections.Generic;
using FARO.CommonDefinition;
using FARO.Covip.DataLayer.EF.Model;
using Microsoft.EntityFrameworkCore;

namespace FARO.Covip.Services {
    public class OutputPortfolioDataService : IOutputPortfolio {
        readonly IConnectionRetriever _connectionRetriever;

        public OutputPortfolioDataService(IConnectionRetriever connectionRetriever) {
            _connectionRetriever = connectionRetriever ?? throw new ArgumentNullException(nameof(connectionRetriever));
        }

        public IEnumerable<string> GetCodes(bool singleFund = false, string fileTransferName = null, params string[] portCodeFilter) {
            _connectionRetriever.Init();
            var cs = _connectionRetriever.GetConnectionString("COVIP") ?? throw new NullReferenceException("Connection not found!");
            var optsBuilder = new DbContextOptionsBuilder<CovipDBContext>().UseSqlServer(cs);

            using var dc = new CovipDBContext(optsBuilder.Options);
            var row = dc.Output.Where(o => o.SingleFund == singleFund);
            if (fileTransferName != null) row = row.Where(o => o.FileTransfer.Name == fileTransferName);
            if (portCodeFilter?.Any() ?? false) row = row.Where(o => portCodeFilter.Contains(o.PortfolioCode));
            return row.Select(o => o.PortfolioCode).Distinct().ToArray();
        }
    }
}
