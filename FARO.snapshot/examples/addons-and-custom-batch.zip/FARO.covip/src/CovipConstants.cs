namespace FARO.Covip {
    public static class CovipConstants {
        public const string ASSET_CLASS_COMPONENTE_NELL_OICR_ESPOSIZIONE_VALUTARIA = "ESP";
        public const string TITOLO_DI_CAPITALE = "TDC";
        public const string TITOLO_DI_DEBITO = "TDD";
        public const string DIVISA_COMPONENTE_NELL_OICR = "F22_DIVISA_COMPONENTE_NELL_OICR";
        public const string STANDARD_PROVIDER_NAME = "STANDARD";
        public const string DESC_DIVISA = "DESC_DIVISA";
        public const string EURO_ISO_CODE = "EUR";
        public const string OICR_SENZA_ESPOSIZIONE_VALUTARIA = "001";
        public const string OICR_CON_ESPOSIZIONE_VALUTARIA = "002";
    }
}
