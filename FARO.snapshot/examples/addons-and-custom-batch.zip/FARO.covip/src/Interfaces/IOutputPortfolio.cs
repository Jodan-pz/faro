using System.Collections.Generic;

namespace FARO.Covip {
    public interface IOutputPortfolio {
        IEnumerable<string> GetCodes(bool singleFund = false, string fileTransferName = null, params string[] portCodeFilter);
    }
}