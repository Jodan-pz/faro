﻿using System;
using System.Collections.Generic;

namespace FARO.Covip.DataLayer.EF.Model {
    public partial class FieldValue {
        public int Id { get; set; }
        public string Provider { get; set; }
        public int FieldSummaryId { get; set; }
        public string Target { get; set; }
        public string Value { get; set; }
        public bool? HasValue { get; set; }

        public FieldSummary FieldSummary { get; set; }
    }
}
