using Microsoft.EntityFrameworkCore;

namespace FARO.Covip.DataLayer.EF.Model {
    public class CovipDBContext : DbContext {
        public CovipDBContext(DbContextOptions options) : base(options) { }

        public virtual DbSet<FieldSummary> FieldSummary { get; set; }
        public virtual DbSet<FieldValue> FieldValue { get; set; }
        public virtual DbSet<Output> Output { get; set; }
        public virtual DbSet<FileTransfer> FileTransfer { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            modelBuilder.Entity<FieldSummary>(entity => {
                entity.ToTable("FieldSummary", "Covip");

                entity.HasIndex(e => new { e.Name, e.IsFixed, e.IsPortfolio })
                    .HasDatabaseName("NonClusteredIndex-20150507-185004")
                    .IsUnique();

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Format)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Scope)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.Source)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FieldValue>(entity => {
                entity.ToTable("FieldValue", "Covip");

                entity.HasIndex(e => new { e.Provider, e.FieldSummaryId, e.Target })
                    .HasDatabaseName("FieldSummaryId_Target_Index")
                    .IsUnique();

                entity.Property(e => e.Provider)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Target)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Value)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.HasOne(d => d.FieldSummary)
                    .WithMany(p => p.FieldValue)
                    .HasForeignKey(d => d.FieldSummaryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FieldValue_FieldSummary");
            });

            modelBuilder.Entity<FileTransfer>(entity => {
                entity.ToTable("FileTransfer", "Covip");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Provider)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TargetContext)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Output>(entity => {
                entity.HasKey(e => e.OuputId);

                entity.ToTable("Output", "Covip");

                entity.HasIndex(e => new { e.PortfolioCode, e.Company, e.FileTransferId })
                    .HasDatabaseName("Idx_PortfolioCompanyFileTransferId")
                    .IsUnique();

                entity.Property(e => e.Company)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PortfolioCode)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.FileTransfer)
                    .WithMany(p => p.Output)
                    .HasForeignKey(d => d.FileTransferId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Output_FileTransfer");
            });
        }
    }
}
