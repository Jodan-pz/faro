﻿using System;
using System.Collections.Generic;

namespace FARO.Covip.DataLayer.EF.Model {
    public partial class Output {
        public int OuputId { get; set; }
        public string PortfolioCode { get; set; }
        public string Company { get; set; }
        public bool SingleFund { get; set; }
        public int FileTransferId { get; set; }

        public virtual FileTransfer FileTransfer { get; set; }
    }
}
