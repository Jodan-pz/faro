﻿using System;
using System.Collections.Generic;

namespace FARO.Covip.DataLayer.EF.Model {
    public partial class FieldSummary {
        public FieldSummary() {
            FieldValue = new HashSet<FieldValue>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsFixed { get; set; }
        public bool IsPortfolio { get; set; }
        public string Scope { get; set; }
        public string Source { get; set; }
        public string Type { get; set; }
        public string Format { get; set; }
        public bool? HasFixedValue { get; set; }

        public ICollection<FieldValue> FieldValue { get; set; }
    }
}
