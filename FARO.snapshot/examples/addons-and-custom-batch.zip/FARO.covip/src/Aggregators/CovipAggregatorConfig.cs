namespace FARO.Covip.Aggregators.Engine {
    public class CovipAggregatorConfig {
        public string ConnectionName { get; set; }
        public string Target { get; set; }
        public string CurrenciesFilePath { get; set; }
        public string Filter { get; set; }
    }
}