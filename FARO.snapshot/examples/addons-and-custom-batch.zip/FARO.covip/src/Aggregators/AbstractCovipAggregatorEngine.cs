using System;
using System.Collections.Generic;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;

namespace FARO.Covip.Aggregators.Engine {
    public abstract class AbstractCovipAggregatorEngine : IAggregatorEngine {
        readonly string _connectionString;
        readonly CovipAggregatorConfig _config;

        protected string ConnectionString => _connectionString;
        protected CovipAggregatorConfig Config => _config;

        public AbstractCovipAggregatorEngine(string connectionString, CovipAggregatorConfig config) {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _config = config ?? throw new ArgumentNullException(nameof(config));
        }

        public abstract IEnumerable<FieldDescription> GetFields(AggregatorDefinition aggregatorDefinition);
        public abstract IEnumerable<string> GetAggregatedFields(AggregatorDefinition aggregatorDefinition);
        public abstract IImageOutput Aggregate(IAggregator aggregator, IImageOutput output, string dataRootPath);
    }
}
