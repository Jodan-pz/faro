using System.Collections.Generic;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;
using Newtonsoft.Json.Linq;
using FARO.Covip.Aggregators.Engine.SARA;
using System;
using FARO.Covip.Aggregators.Engine.STATESTREET;

namespace FARO.Covip.Aggregators.Engine {
    public class CovipAggregatorEngine : IAggregatorEngine {
        readonly IConnectionRetriever _connectionRetriever;
        public CovipAggregatorEngine(IConnectionRetriever connectionRetriever) {
            _connectionRetriever = connectionRetriever ?? throw new ArgumentNullException(nameof(connectionRetriever));
        }

        IAggregatorEngine GetImpl(AggregatorDefinition aggregatorDefinition) {
            var cfg = aggregatorDefinition.Config["value"];
            CovipAggregatorConfig config;
            if (cfg is CovipAggregatorConfig covipAggrConfig) config = covipAggrConfig;
            else config = ((JObject)cfg).ToObject<CovipAggregatorConfig>();
            _connectionRetriever.Init();
            var cs = _connectionRetriever.GetConnectionString(config.ConnectionName) ?? throw new NullReferenceException($"Cannot find connection {config.ConnectionName}");
            IAggregatorEngine impl = null;
            switch (config.Target?.ToUpper() ?? string.Empty) {
                case "STANDARD_LTOICR":
                    impl = new StandardLookThroughAggregator(cs, config);
                    break;
                case "SARA":
                    impl = new SARA_Aggregator(cs, config);
                    break;
                case "STATESTREET":
                    impl = new STATESTREET_Aggregator(cs, config);
                    break;
                case "STANDARD_PANIND":
                    impl = new StandardPanindAggregator(cs, config);
                    break;
                default:
                    break;

            }
            return impl;
        }

        public IImageOutput Aggregate(IAggregator aggregator, IImageOutput output, string dataRootPath) => GetImpl(aggregator.Definition)?.Aggregate(aggregator, output, dataRootPath);
        public IEnumerable<FieldDescription> GetFields(AggregatorDefinition aggregatorDefinition) => GetImpl(aggregatorDefinition)?.GetFields(aggregatorDefinition);
        public IEnumerable<string> GetAggregatedFields(AggregatorDefinition aggregatorDefinition) => GetImpl(aggregatorDefinition)?.GetAggregatedFields(aggregatorDefinition);
    }
}
