namespace FARO.Covip.Aggregators.Engine {

    public enum AggregateValueCategory {
        AreaGeografica,
        Emittete_Rating,
        Emittente_Duration,
        SettoreAttivitaEconomica,
        Valuta
    }

    public class AggregateValue {
        public AggregateValueCategory Category { get; internal set; }
        public string Area { get; internal set; }
        public string AssetClass { get; internal set; }
        public string Duration { get; internal set; }
        public string Emittente { get; internal set; }
        public string Settore { get; internal set; }
        public string Rating { get; internal set; }
        public string Valuta { get; internal set; }
        public string ValutaLongDescription { get; internal set; }

        public double? Value { get; internal set; }

        public AggregateValue(AggregateValueCategory category) {
            Category = category;
        }

        public bool HasValue {
            get {
                return Value != null;
            }
        }
    }

}