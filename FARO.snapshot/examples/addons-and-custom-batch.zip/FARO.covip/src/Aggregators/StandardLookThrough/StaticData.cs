using System.Collections.Generic;
using static FARO.Covip.Aggregators.Engine.AggregatedLookThroughFields;

namespace FARO.Covip.Aggregators.Engine {
    public static class AggregateStaticData {

        public const string DOMAIN1_CODE = "D9999";
        public const string DOMAIN1_VALUE_TDC = "AZION";
        public const string DOMAIN1_VALUE_TDD = "OBLIG";
        public const string DOMAIN1_VALUE_VALUTA = "TVALU";

        public const string CODE_AREA_GEOGRAFICA = "D0023";
        public const string CODE_EMITTENTE = "D0028";
        public const string CODE_RATING = "D0029";
        public const string CODE_DURATION = "D0031";
        public const string CODE_SETTORE_ATTIVITA_ECONOMICA = "D0032";
        public const string CODE_VALUTA = "D0203";

        readonly public static Dictionary<AggregatedLookThroughFields, string> LT_AREA_MAP = new Dictionary<AggregatedLookThroughFields, string> {
            { ITALIA_TDD,  "001" } , { ITALIA_TDC,  "001" },
            { ALTRI_PAESI_AREA_EURO_TDD,  "002" } , { ALTRI_PAESI_AREA_EURO_TDC,  "002" },
            { ALTRI_PAESI_UNIONE_EUROPEA_TDD, "003"} , { ALTRI_PAESI_UNIONE_EUROPEA_TDC, "003"},
            { STATI_UNITI_TDD, "004"} , { STATI_UNITI_TDC, "004"},
            { GIAPPONE_TDD, "005"} , { GIAPPONE_TDC, "005"},
            { ALTRI_PAESI_ADERENTI_OCSE_TDD, "006" } , { ALTRI_PAESI_ADERENTI_OCSE_TDC, "006" },
            { ALTRI_PAESI_NON_ADERENTI_OCSE_TDD, "007" } , { ALTRI_PAESI_NON_ADERENTI_OCSE_TDC, "007"}
        };

        readonly public static Dictionary<AggregatedLookThroughFields, string> LT_SETTORE_MAP = new Dictionary<AggregatedLookThroughFields, string> {
            { ENERGIA,  "001" },
            { MATERIALI,  "002" },
            { INDUSTRIALE,  "003" },
            { BENI_DI_CONSUMO_CICLICI,  "004" },
            { BENI_DI_CONSUMO_NON_CICLICI,  "005" },
            { SANITARIO,  "006" },
            { FINANZIARIO,  "007" },
            { IT,  "008" },
            { SERVIZI_PER_TELECOMUNICAZIONI,  "009" },
            { UTILITIES,  "010" },
            { REAL_ESTATE,  "011" }
        };

        readonly public static Dictionary<AggregatedLookThroughFields, string> LT_EMITTENTE_MAP = new Dictionary<AggregatedLookThroughFields, string> {
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_INVESTMENT_GRADE,  "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_NON_INVESTMENT_GRADE, "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_PRIVO_DI_RATING, "001" },

            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_INFERIORE_A_1_ANNO,  "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_1_E_3_ANNI, "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_3_E_10_ANNI, "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_SUPERIORE_A_10_ANNI, "001" },

            { IMPRESE_FINANZIARIE_INVESTMENT_GRADE, "004" },
            { IMPRESE_FINANZIARIE_NON_INVESTMENT_GRADE, "004"},
            { IMPRESE_FINANZIARIE_PRIVO_DI_RATING, "004" },

            { IMPRESE_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO,  "004" },
            { IMPRESE_FINANZIARIE_DURATA_TRA_1_E_3_ANNI, "004" },
            { IMPRESE_FINANZIARIE_DURATA_TRA_3_E_10_ANNI, "004" },
            { IMPRESE_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI, "004" },

            { IMPRESE_NON_FINANZIARIE_INVESTMENT_GRADE, "013" },
            { IMPRESE_NON_FINANZIARIE_NON_INVESTMENT_GRADE, "013"},
            { IMPRESE_NON_FINANZIARIE_PRIVO_DI_RATING, "013" },

            { IMPRESE_NON_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO, "013" },
            { IMPRESE_NON_FINANZIARIE_DURATA_TRA_1_E_3_ANNI, "013"},
            { IMPRESE_NON_FINANZIARIE_DURATA_TRA_3_E_10_ANNI, "013" },
            { IMPRESE_NON_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI, "013"}

        };

        readonly public static Dictionary<AggregatedLookThroughFields, string> LT_DURATION_MAP = new Dictionary<AggregatedLookThroughFields, string> {
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_INFERIORE_A_1_ANNO,  "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_1_E_3_ANNI, "002" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_3_E_10_ANNI, "003" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_SUPERIORE_A_10_ANNI, "004" },

            { IMPRESE_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO,  "001" },
            { IMPRESE_FINANZIARIE_DURATA_TRA_1_E_3_ANNI, "002" },
            { IMPRESE_FINANZIARIE_DURATA_TRA_3_E_10_ANNI, "003" },
            { IMPRESE_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI, "004" },

            { IMPRESE_NON_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO,  "001" },
            { IMPRESE_NON_FINANZIARIE_DURATA_TRA_1_E_3_ANNI, "002" },
            { IMPRESE_NON_FINANZIARIE_DURATA_TRA_3_E_10_ANNI, "003" },
            { IMPRESE_NON_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI, "004" }
        };

        readonly public static Dictionary<AggregatedLookThroughFields, string> LT_RATING_MAP = new Dictionary<AggregatedLookThroughFields, string> {
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_INVESTMENT_GRADE,  "001" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_NON_INVESTMENT_GRADE, "002" },
            { STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_PRIVO_DI_RATING, "003" },

            { IMPRESE_FINANZIARIE_INVESTMENT_GRADE,  "001" },
            { IMPRESE_FINANZIARIE_NON_INVESTMENT_GRADE, "002" },
            { IMPRESE_FINANZIARIE_PRIVO_DI_RATING, "003" },

            { IMPRESE_NON_FINANZIARIE_INVESTMENT_GRADE,  "001" },
            { IMPRESE_NON_FINANZIARIE_NON_INVESTMENT_GRADE, "002" },
            { IMPRESE_NON_FINANZIARIE_PRIVO_DI_RATING, "003" }
        };

        readonly public static Dictionary<string, string> AREA_DES = new Dictionary<string, string> {
            { "001", "Italia" },
            { "002", "Altri Paese Area Euro" },
            { "003", "Altri Paesi Unione Europea" },
            { "004", "Stati Uniti" },
            { "005", "Giappone" },
            { "006", "Altri Paesi aderenti OCSE" },
            { "007", "Altri Paesi NON aderenti OCSE" }
        };

        readonly public static Dictionary<string, string> SETTORE_ATTIVITA_ECONOMICA_DES = new Dictionary<string, string> {
            { "001", "Energia" },
            { "002", "Materiali" },
            { "003", "Industriale" },
            { "004", "Beni di Consumo Ciclici" },
            { "005", "Beni di Consumo NON Ciclici" },
            { "006", "Sanitario" },
            { "007", "Finanziario" },
            { "008", "IT" },
            { "009", "Servizi per Telecomunicazioni" },
            { "010", "Utilities" },
            { "011", "Real Estate" }
        };

        readonly public static Dictionary<string, string> EMITTENTE_DES = new Dictionary<string, string> {
            { "001", "Stati ed altri organismi internazionali" },
            { "004", "Imprese Finanziarie" },
            { "013", "Imprese NON Finanziarie" }
        };

        readonly public static Dictionary<string, string> RATING_DES = new Dictionary<string, string> {
            { "001", "Investment Grade" },
            { "002", "Non Investment Grade" },
            { "003", "Privo di Rating" }
        };

        readonly public static Dictionary<string, string> DURATION_DES = new Dictionary<string, string> {
            { "001", "Duration <= 1 anno" },
            { "002", "1 anno < Duration <= 3" },
            { "003", "3 anni < Duration <= 10 anni" },
            { "004", "Duration > 10 anni" }
        };
    }
}