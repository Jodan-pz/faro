using System;
using System.Collections.Generic;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;

namespace FARO.Covip.Aggregators.Engine.SARA {
    public class SARA_Aggregator : StandardLookThroughAggregator {
        public SARA_Aggregator(string connectionString, CovipAggregatorConfig config) : base(connectionString, config) { }

        public override IEnumerable<string> GetAggregatedFields(AggregatorDefinition aggregatorDefinition) => Enum.GetNames(typeof(SARA_Fields));

        protected override IImageOutput OnAggregate(IAggregator aggregator, IImageOutput output, string dataRootPath) {
            var result = new ImageOutput();

            var alt = new AggregatedLookThrough(ConnectionString);
            var collector = alt.Collect(output);

            var toAdd = result.AddKey();
            toAdd.SetValue(SARA_Fields.IS_CURRENCY.ToString(), false);
            foreach (SARA_Fields saraField in Enum.GetValues(typeof(SARA_Fields))) {
                var fieldName = saraField.ToString();
                if (collector.ContainsField(fieldName)) {
                    toAdd.SetValue(saraField.ToString(), collector[fieldName]?.Value / 100);
                }
            }
            uint divCount = 1;
            foreach (var currency in collector.GetCurrencies()) {
                var currencyToAdd = result.AddKey();
                var divisa = currency.Valuta;
                var descrizione = currency.ValutaLongDescription;
                var valore = currency.Value;
                currencyToAdd.SetValue(SARA_Fields.IS_CURRENCY.ToString(), true);
                currencyToAdd.SetValue(SARA_Fields.DIVISA_INDEX.ToString(), divCount++);
                currencyToAdd.SetValue(SARA_Fields.DIVISA_NOME.ToString(), divisa);
                currencyToAdd.SetValue(SARA_Fields.DIVISA_DESCRIZIONE.ToString(), descrizione);
                currencyToAdd.SetValue(SARA_Fields.DIVISA_VALORE.ToString(), valore / 100);
            }

            return result;
        }
    }
}
