using System;
using System.Collections.Generic;
using System.Linq;
using FARO.CommonDefinition;
using FARO.Covip.DataLayer.EF.Model;
using Microsoft.EntityFrameworkCore;
using static FARO.Covip.Aggregators.Engine.AggregatedLookThroughFields;
using static FARO.Covip.Aggregators.Engine.AggregateStaticData;

namespace FARO.Covip.Aggregators.Engine {
    public class AggregatedLookThrough {
        #region Private
        private readonly string _connectionString;
        private readonly Dictionary<string, (string code, string longDescription)> _divise;
        private List<AggregatedLookThroughRow> _rows;
        private double? _totalNAV;
        #endregion

        #region Aggregation Functions

        IEnumerable<AggregateValue> GetCurrencyValues() {
            foreach (var val in _rows.Where(p => p.AssetClass == CovipConstants.ASSET_CLASS_COMPONENTE_NELL_OICR_ESPOSIZIONE_VALUTARIA)) {
                var (code, longDescription) = GetDivisa(val.ValutaUIC);
                yield return new AggregateValue(AggregateValueCategory.Valuta)
                {
                    AssetClass = val.AssetClass,
                    Valuta = code,
                    ValutaLongDescription = longDescription,
                    Value = val.ControvaloreEsposizione
                };
            }
        }

        (string code, string longDescription) GetDivisa(string uicCode) => _divise.ContainsKey(uicCode) ? _divise[uicCode] : (code: uicCode, longDescription: null);

        AggregateValue GetAggregationValue(Func<AggregatedLookThroughRow, bool> condition,
                                           AggregateValueCategory category,
                                           string assetClass = null,
                                           string area = null,
                                           string emittente = null,
                                           string rating = null,
                                           string duration = null,
                                           string settore = null,
                                           string valuta = null) {
            double? value = null;
            if ((_totalNAV ?? 0) != 0) {
                var ret = _rows.Where(condition).Sum(r => r.ControvaloreNAV);
                if ((ret ?? 0) != 0) {
                    value = ret / _totalNAV;
                }
            }

            return new AggregateValue(category)
            {
                Value = value,
                AssetClass = assetClass,
                Area = area,
                Emittente = emittente,
                Rating = rating,
                Duration = duration,
                Settore = settore,
                Valuta = valuta
            };
        }

        AggregateValue GetByAreaGeograficaTDD(AggregatedLookThroughFields field) => GetByAreaGeograficaTDD(LT_AREA_MAP[field]);
        AggregateValue GetByAreaGeograficaTDC(AggregatedLookThroughFields field) => GetByAreaGeograficaTDC(LT_AREA_MAP[field]);
        AggregateValue GetByEmittenteAndRating(AggregatedLookThroughFields field) => GetByEmittenteAndRating(emittente: LT_EMITTENTE_MAP[field], rating: LT_RATING_MAP[field]);
        AggregateValue GetByEmittenteAndDuration(AggregatedLookThroughFields field) => GetByEmittenteAndDuration(emittente: LT_EMITTENTE_MAP[field], duration: LT_DURATION_MAP[field]);
        AggregateValue GetBySettoreAttivitaEconomica(AggregatedLookThroughFields settoreField) => GetBySettoreAttivitaEconomica(LT_SETTORE_MAP[settoreField]);

        AggregateValue GetByAreaGeograficaTDD(string area) => GetAggregationValue(p => p.AssetClass == CovipConstants.TITOLO_DI_DEBITO &&
                                                                                  p.AreaGeografica == area,
                                                                                  AggregateValueCategory.AreaGeografica,
                                                                                  assetClass: CovipConstants.TITOLO_DI_DEBITO,
                                                                                  area: area);

        AggregateValue GetByAreaGeograficaTDC(string area) => GetAggregationValue(p => p.AssetClass == CovipConstants.TITOLO_DI_CAPITALE &&
                                                                                  p.AreaGeografica == area,
                                                                                  AggregateValueCategory.AreaGeografica,
                                                                                  assetClass: CovipConstants.TITOLO_DI_CAPITALE,
                                                                                  area: area);

        AggregateValue GetByEmittenteAndRating(string emittente, string rating) =>
            GetAggregationValue(p => p.AssetClass == CovipConstants.TITOLO_DI_DEBITO &&
                                     p.CategoriaEmittente == emittente &&
                                     p.Rating == rating,
                                     AggregateValueCategory.Emittete_Rating, assetClass: CovipConstants.TITOLO_DI_DEBITO, emittente: emittente, rating: rating);


        AggregateValue GetByEmittenteAndDuration(string emittente, string duration) =>
           GetAggregationValue(p => p.AssetClass == CovipConstants.TITOLO_DI_DEBITO &&
                                    p.CategoriaEmittente == emittente &&
                                    p.FasciaDuration == duration,
                                    AggregateValueCategory.Emittente_Duration, assetClass: CovipConstants.TITOLO_DI_DEBITO, emittente: emittente, duration: duration);

        AggregateValue GetBySettoreAttivitaEconomica(string settore) =>
            GetAggregationValue(p => p.AssetClass == CovipConstants.TITOLO_DI_CAPITALE &&
                                     p.SettoreAttivitaEconomica == settore,
                                      AggregateValueCategory.SettoreAttivitaEconomica, assetClass: CovipConstants.TITOLO_DI_CAPITALE, settore: settore);

        #endregion


        public AggregatedLookThrough(string connectionString) {
            _connectionString = connectionString;
            // prefill fixed values
            var optsBuilder = new DbContextOptionsBuilder<CovipDBContext>().UseSqlServer(_connectionString);
            using var dc = new CovipDBContext(optsBuilder.Options);
            var diviseCodes = (from f in dc.FieldValue
                               where f.FieldSummary.IsFixed &&
                                     !f.FieldSummary.IsPortfolio &&
                                     f.FieldSummary.Name == CovipConstants.DIVISA_COMPONENTE_NELL_OICR &&
                                     f.Provider == CovipConstants.STANDARD_PROVIDER_NAME
                               select f).ToDictionary(k => k.Target, v => v.Value);
            var diviseLongDesc = (from f in dc.FieldValue
                                  where f.FieldSummary.IsFixed &&
                                        !f.FieldSummary.IsPortfolio &&
                                        f.FieldSummary.Name == CovipConstants.DESC_DIVISA &&
                                        f.Provider == CovipConstants.STANDARD_PROVIDER_NAME
                                  select f).ToDictionary(k => k.Target, v => v.Value);
            _divise = new Dictionary<string, (string Code, string LongDescription)>();
            foreach (var code in diviseCodes) {
                if (code.Value == null) continue;
                var longDes = diviseLongDesc.ContainsKey(code.Key) ? diviseLongDesc[code.Key] : "MISSING LONG DESCRIPTION!!!";
                if (!_divise.ContainsKey(code.Value)) {
                    _divise.Add(code.Value, (code: code.Key, longDescription: longDes));
                }
            }
        }

        public AggregatedLookThroughRowCollector Collect(IImageOutput output) {
            _rows = new List<AggregatedLookThroughRow>();
            output.IterateRows(row => _rows.Add(new AggregatedLookThroughRow
            {
                ReferenceDate = row.GetValueExact(StandardLTImageFieldNames.REFERENCE_DATE.ToString())?.ToString(),
                AssetClass = row.GetValueExact(StandardLTImageFieldNames.ASSET_CLASS_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                AreaGeografica = row.GetValueExact(StandardLTImageFieldNames.AREA_GEOGRAFICA_EMITTENTE_SINGOLO_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                CategoriaEmittente = row.GetValueExact(StandardLTImageFieldNames.CATEGORIA_EMITTENTE_SINGOLO_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                FasciaDuration = row.GetValueExact(StandardLTImageFieldNames.FASCIA_DURATION_SINGOLO_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                ValutaUIC = row.GetValueExact(StandardLTImageFieldNames.DIVISA_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                Rating = row.GetValueExact(StandardLTImageFieldNames.RATING_SINGOLO_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                SettoreAttivitaEconomica = row.GetValueExact(StandardLTImageFieldNames.SETTORE_ATT_ECONOMICA_SINGOLO_COMPONENTE_NELL_OICR.ToString())?.ToString(),
                ControvaloreEsposizione = row.GetValueExactAs<double>(StandardLTImageFieldNames.CONTROVALORE_ESPOSIZIONE_COMPONENTE_OICR.ToString()),
                ControvaloreNAV = row.GetValueExactAs<double>(StandardLTImageFieldNames.CONTROVALORE_NAV_COMPONENTE_OICR.ToString())
            }));

            _totalNAV = _rows.Sum(r => r.ControvaloreNAV);

            var collector = new AggregatedLookThroughRowCollector(_rows.First().ReferenceDate);

            /**
             * Area Geografica (TDD/TDC)
             **/
            collector.Set(ITALIA_TDD, GetByAreaGeograficaTDD(ITALIA_TDD));
            collector.Set(ALTRI_PAESI_AREA_EURO_TDD, GetByAreaGeograficaTDD(ALTRI_PAESI_AREA_EURO_TDD));
            collector.Set(ALTRI_PAESI_UNIONE_EUROPEA_TDD, GetByAreaGeograficaTDD(ALTRI_PAESI_UNIONE_EUROPEA_TDD));
            collector.Set(STATI_UNITI_TDD, GetByAreaGeograficaTDD(STATI_UNITI_TDD));
            collector.Set(GIAPPONE_TDD, GetByAreaGeograficaTDD(GIAPPONE_TDD));
            collector.Set(ALTRI_PAESI_ADERENTI_OCSE_TDD, GetByAreaGeograficaTDD(ALTRI_PAESI_ADERENTI_OCSE_TDD));
            collector.Set(ALTRI_PAESI_NON_ADERENTI_OCSE_TDD, GetByAreaGeograficaTDD(ALTRI_PAESI_NON_ADERENTI_OCSE_TDD));

            collector.Set(ITALIA_TDC, GetByAreaGeograficaTDC(ITALIA_TDC));
            collector.Set(ALTRI_PAESI_AREA_EURO_TDC, GetByAreaGeograficaTDC(ALTRI_PAESI_AREA_EURO_TDC));
            collector.Set(ALTRI_PAESI_UNIONE_EUROPEA_TDC, GetByAreaGeograficaTDC(ALTRI_PAESI_UNIONE_EUROPEA_TDC));
            collector.Set(STATI_UNITI_TDC, GetByAreaGeograficaTDC(STATI_UNITI_TDC));
            collector.Set(GIAPPONE_TDC, GetByAreaGeograficaTDC(GIAPPONE_TDC));
            collector.Set(ALTRI_PAESI_ADERENTI_OCSE_TDC, GetByAreaGeograficaTDC(ALTRI_PAESI_ADERENTI_OCSE_TDC));
            collector.Set(ALTRI_PAESI_NON_ADERENTI_OCSE_TDC, GetByAreaGeograficaTDC(ALTRI_PAESI_NON_ADERENTI_OCSE_TDC));

            /**
             * Categoria Emittente + Rating
             **/
            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_INVESTMENT_GRADE, GetByEmittenteAndRating(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_INVESTMENT_GRADE));
            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_NON_INVESTMENT_GRADE, GetByEmittenteAndRating(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_NON_INVESTMENT_GRADE));
            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_PRIVO_DI_RATING, GetByEmittenteAndRating(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_PRIVO_DI_RATING));

            collector.Set(IMPRESE_FINANZIARIE_INVESTMENT_GRADE, GetByEmittenteAndRating(IMPRESE_FINANZIARIE_INVESTMENT_GRADE));
            collector.Set(IMPRESE_FINANZIARIE_NON_INVESTMENT_GRADE, GetByEmittenteAndRating(IMPRESE_FINANZIARIE_NON_INVESTMENT_GRADE));
            collector.Set(IMPRESE_FINANZIARIE_PRIVO_DI_RATING, GetByEmittenteAndRating(IMPRESE_FINANZIARIE_PRIVO_DI_RATING));

            collector.Set(IMPRESE_NON_FINANZIARIE_INVESTMENT_GRADE, GetByEmittenteAndRating(IMPRESE_NON_FINANZIARIE_INVESTMENT_GRADE));
            collector.Set(IMPRESE_NON_FINANZIARIE_NON_INVESTMENT_GRADE, GetByEmittenteAndRating(IMPRESE_NON_FINANZIARIE_NON_INVESTMENT_GRADE));
            collector.Set(IMPRESE_NON_FINANZIARIE_PRIVO_DI_RATING, GetByEmittenteAndRating(IMPRESE_NON_FINANZIARIE_PRIVO_DI_RATING));

            /**
             * Categoria Emittente + Fascia Duration
             **/

            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_INFERIORE_A_1_ANNO, GetByEmittenteAndDuration(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_INFERIORE_A_1_ANNO));
            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_1_E_3_ANNI, GetByEmittenteAndDuration(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_1_E_3_ANNI));
            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_3_E_10_ANNI, GetByEmittenteAndDuration(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_TRA_3_E_10_ANNI));
            collector.Set(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_SUPERIORE_A_10_ANNI, GetByEmittenteAndDuration(STATI_ED_ALTRI_ORGANISMI_INTERNAZIONALI_DURATA_SUPERIORE_A_10_ANNI));

            collector.Set(IMPRESE_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO, GetByEmittenteAndDuration(IMPRESE_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO));
            collector.Set(IMPRESE_FINANZIARIE_DURATA_TRA_1_E_3_ANNI, GetByEmittenteAndDuration(IMPRESE_FINANZIARIE_DURATA_TRA_1_E_3_ANNI));
            collector.Set(IMPRESE_FINANZIARIE_DURATA_TRA_3_E_10_ANNI, GetByEmittenteAndDuration(IMPRESE_FINANZIARIE_DURATA_TRA_3_E_10_ANNI));
            collector.Set(IMPRESE_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI, GetByEmittenteAndDuration(IMPRESE_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI));

            collector.Set(IMPRESE_NON_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO, GetByEmittenteAndDuration(IMPRESE_NON_FINANZIARIE_DURATA_INFERIORE_A_1_ANNO));
            collector.Set(IMPRESE_NON_FINANZIARIE_DURATA_TRA_1_E_3_ANNI, GetByEmittenteAndDuration(IMPRESE_NON_FINANZIARIE_DURATA_TRA_1_E_3_ANNI));
            collector.Set(IMPRESE_NON_FINANZIARIE_DURATA_TRA_3_E_10_ANNI, GetByEmittenteAndDuration(IMPRESE_NON_FINANZIARIE_DURATA_TRA_3_E_10_ANNI));
            collector.Set(IMPRESE_NON_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI, GetByEmittenteAndDuration(IMPRESE_NON_FINANZIARIE_DURATA_SUPERIORE_A_10_ANNI));

            /**
             *  Settore Attività Economica 
             **/
            collector.Set(ENERGIA, GetBySettoreAttivitaEconomica(ENERGIA));
            collector.Set(MATERIALI, GetBySettoreAttivitaEconomica(MATERIALI));
            collector.Set(INDUSTRIALE, GetBySettoreAttivitaEconomica(INDUSTRIALE));
            collector.Set(BENI_DI_CONSUMO_CICLICI, GetBySettoreAttivitaEconomica(BENI_DI_CONSUMO_CICLICI));
            collector.Set(BENI_DI_CONSUMO_NON_CICLICI, GetBySettoreAttivitaEconomica(BENI_DI_CONSUMO_NON_CICLICI));
            collector.Set(SANITARIO, GetBySettoreAttivitaEconomica(SANITARIO));
            collector.Set(FINANZIARIO, GetBySettoreAttivitaEconomica(FINANZIARIO));
            collector.Set(IT, GetBySettoreAttivitaEconomica(IT));
            collector.Set(SERVIZI_PER_TELECOMUNICAZIONI, GetBySettoreAttivitaEconomica(SERVIZI_PER_TELECOMUNICAZIONI));
            collector.Set(UTILITIES, GetBySettoreAttivitaEconomica(UTILITIES));
            collector.Set(REAL_ESTATE, GetBySettoreAttivitaEconomica(REAL_ESTATE));

            /**
             * Valute
             **/
            foreach (var val in GetCurrencyValues()) collector.AddCurrency(val);
            return collector;
        }
    }
}
