using System;
using System.Collections.Generic;


namespace FARO.Covip.Aggregators.Engine {
    public class AggregatedLookThroughRowCollector {
        readonly string _referenceDate;
        readonly Dictionary<string, AggregateValue> _values;
        readonly List<AggregateValue> _currencies;

        public AggregatedLookThroughRowCollector(string referenceDate) {
            _referenceDate = referenceDate;
            _values = new Dictionary<string, AggregateValue>();
            _currencies = new List<AggregateValue>();
            /*
             *  Init Dict
             */
            foreach (var name in Enum.GetNames(typeof(AggregatedLookThroughFields))) {
                _values.Add(name, null);
            }
        }

        public string ReferenceDate => _referenceDate;
        public IEnumerable<AggregateValue> AsEnumerable() => _values.Values;

        public AggregateValue this[string fieldName] => _values[fieldName];
        public AggregateValue this[AggregatedLookThroughFields fieldName] => _values[fieldName.ToString()];

        public bool ContainsField(string fieldName) => _values.ContainsKey(fieldName);

        public void Set(AggregatedLookThroughFields field, AggregateValue value) => _values[field.ToString()] = value;

        public void AddCurrency(AggregateValue value) => _currencies.Add(value);

        public IEnumerable<AggregateValue> GetCurrencies() => _currencies;
    }
}