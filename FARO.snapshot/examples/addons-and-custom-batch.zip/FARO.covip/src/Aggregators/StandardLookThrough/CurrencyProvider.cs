using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using static FARO.Covip.CovipConstants;
namespace FARO.Covip.Aggregators.Engine {
    public class CurrencyProvider {
        #region Inner classes for Value and Row
        public class CurrencyPercValue {
            public string ISOCode { get; set; }
            public decimal Value { get; internal set; }
        }

        public class CurrencyPercRow {
            readonly Func<KeyValuePair<string, decimal>, bool> _currencyCondition = (kv) => kv.Key != EURO_ISO_CODE && kv.Value != 0;
            readonly Dictionary<string, decimal> _currencies = new Dictionary<string, decimal>();

            bool ContainsOtherThanEuro => _currencies.Any(_currencyCondition);

            public void AddCurrency(string currency, decimal value) {
                if (_currencies.ContainsKey(currency)) {
                    _currencies[currency] += value;
                } else {
                    _currencies.Add(currency, value);
                }
            }

            public bool HasCurrencies => _currencies.Any();
            /// <summary>
            /// In base al prospetto/regolamento dell’OICR/ETF, indica se è prevista una copertura al 100% dell’esposizione valutaria e 
            /// quindi lo strumento nel suo complesso non presenta alcuna esposizione.
            /// Può assumere i seguenti valori:
            /// 001 – OICR con copertura dell’esposizione valutaria pari al 100% oppure OICR con sottostanti solo riferiti alla divisa EUR
            ///	002 – OICR con copertura dell’esposizione valutaria inferiore al 100%
            /// </summary>
            public string CoperturaEsposizioneValutariaOICR => _currencies.Any() ? (ContainsOtherThanEuro ? OICR_CON_ESPOSIZIONE_VALUTARIA : OICR_SENZA_ESPOSIZIONE_VALUTARIA) : null;

            public IEnumerable<CurrencyPercValue> CurrencyValuesExceptEuro {
                get {
                    foreach (var currency in _currencies.Where(_currencyCondition)) {
                        yield return new CurrencyPercValue { ISOCode = currency.Key, Value = currency.Value };
                    }
                }
            }
        }

        internal CurrencyPercRow GetByIsin(string isinCode) => _values.ContainsKey(isinCode) ? _values[isinCode] : null;

        #endregion

        ConcurrentDictionary<string, CurrencyPercRow> _values;

        internal void LoadText(string currenciesFilePath) {
            _values = new ConcurrentDictionary<string, CurrencyPercRow>();

            using var rdr = File.OpenText(currenciesFilePath);
            while (!rdr.EndOfStream) {
                var line = rdr.ReadLine().Split(';');
                if (string.IsNullOrEmpty(line[1])) continue;

                var isinCode = line[4];
                var curCode = line[5];
                var val = line[6].TrimEnd('%').Replace(",", ".");

                CurrencyPercRow row;
                if (!_values.ContainsKey(isinCode)) {
                    row = new CurrencyPercRow();
                    _values.TryAdd(isinCode, row);
                } else {
                    row = _values[isinCode];
                }

                if (decimal.TryParse(val, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var curVal)) {
                    row.AddCurrency(curCode, curVal);
                }
            }
        }
    }
}
