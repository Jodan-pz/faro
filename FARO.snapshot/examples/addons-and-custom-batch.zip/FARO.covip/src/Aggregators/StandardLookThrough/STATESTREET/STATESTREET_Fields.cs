namespace FARO.Covip.Aggregators.Engine.STATESTREET {
    public enum STATESTREET_Fields {
        IS_CURRENCY,

        REFERENCE_DATE,
        ISIN_CODE,
        SIGNALIZATION_DATE,
        DOMAIN_1_CODE,
        DOMAIN_1_VALUE,
        DOMAIN_2_CODE,
        DOMAIN_2_VALUE,
        DOMAIN_2_DESCRIPTION,
        DOMAIN_3_CODE,
        DOMAIN_3_VALUE,
        DOMAIN_3_DESCRIPTION,
        DOMAIN_4_CODE,
        DOMAIN_4_VALUE,
        DOMAIN_4_DESCRIPTION,
        DOMAIN_5_CODE,
        DOMAIN_5_VALUE,
        DOMAIN_5_DESCRIPTION,
        PERC_WITHOUT_LT,
        PERC_WITH_LT
    }
}