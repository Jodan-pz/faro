using System;
using System.Collections.Generic;
using System.Linq;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;

namespace FARO.Covip.Aggregators.Engine.STATESTREET {
    public class STATESTREET_Aggregator : StandardLookThroughAggregator {
        enum DomainKind { Code, Value, Description }

        public STATESTREET_Aggregator(string connectionString, CovipAggregatorConfig config) : base(connectionString, config) { }

        public override IEnumerable<string> GetAggregatedFields(AggregatorDefinition aggregatorDefinition) => Enum.GetNames(typeof(STATESTREET_Fields));

        protected override IImageOutput OnAggregate(IAggregator aggregator, IImageOutput output, string dataRootPath) {
            var result = new ImageOutput();

            var groupsByIsinCode = new Dictionary<string, ImageOutput>();
            output.IterateRows(row => {
                ImageOutput grouped = null;
                var isinCode = row.GetValueExact(StandardLTImageFieldNames.CODICE_ISIN_OICR.ToString()).ToString();
                if (groupsByIsinCode.ContainsKey(isinCode)) {
                    grouped = groupsByIsinCode[isinCode];
                } else {
                    groupsByIsinCode.Add(isinCode, grouped = new ImageOutput());
                }
                grouped.AddRow(row);
            });

            var alt = new AggregatedLookThrough(ConnectionString);
            foreach (var group in groupsByIsinCode) {
                var collector = alt.Collect(group.Value);

                foreach (var field in collector.AsEnumerable().Where(r => r.HasValue)) {
                    var row = result.AddKey();
                    row.SetValue(STATESTREET_Fields.IS_CURRENCY.ToString(), false);
                    row.SetValue(STATESTREET_Fields.ISIN_CODE.ToString(), group.Key);
                    row.SetValue(STATESTREET_Fields.SIGNALIZATION_DATE.ToString(), collector.ReferenceDate);

                    row.SetValue(STATESTREET_Fields.DOMAIN_1_CODE.ToString(), Domain(1, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_1_VALUE.ToString(), Domain(1, DomainKind.Value, field));

                    row.SetValue(STATESTREET_Fields.DOMAIN_2_CODE.ToString(), Domain(2, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_2_VALUE.ToString(), Domain(2, DomainKind.Value, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_2_DESCRIPTION.ToString(), Domain(2, DomainKind.Description, field));

                    row.SetValue(STATESTREET_Fields.DOMAIN_3_CODE.ToString(), Domain(3, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_3_VALUE.ToString(), Domain(3, DomainKind.Value, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_3_DESCRIPTION.ToString(), Domain(3, DomainKind.Description, field));

                    row.SetValue(STATESTREET_Fields.DOMAIN_4_CODE.ToString(), Domain(4, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_4_VALUE.ToString(), Domain(4, DomainKind.Value, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_4_DESCRIPTION.ToString(), Domain(4, DomainKind.Description, field));

                    row.SetValue(STATESTREET_Fields.DOMAIN_5_CODE.ToString(), Domain(5, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_5_VALUE.ToString(), Domain(5, DomainKind.Value, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_5_DESCRIPTION.ToString(), Domain(5, DomainKind.Description, field));

                    row.SetValue(STATESTREET_Fields.PERC_WITHOUT_LT.ToString(), field.Value);
                    row.SetValue(STATESTREET_Fields.PERC_WITH_LT.ToString(), field.Value);
                }

                foreach (var field in collector.GetCurrencies()) {
                    var row = result.AddKey();
                    row.SetValue(STATESTREET_Fields.IS_CURRENCY.ToString(), true);
                    row.SetValue(STATESTREET_Fields.ISIN_CODE.ToString(), group.Key);
                    row.SetValue(STATESTREET_Fields.SIGNALIZATION_DATE.ToString(), collector.ReferenceDate);

                    row.SetValue(STATESTREET_Fields.DOMAIN_1_CODE.ToString(), Domain(1, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_1_VALUE.ToString(), Domain(1, DomainKind.Value, field));

                    row.SetValue(STATESTREET_Fields.DOMAIN_2_CODE.ToString(), Domain(2, DomainKind.Code, field));
                    row.SetValue(STATESTREET_Fields.DOMAIN_2_VALUE.ToString(), Domain(2, DomainKind.Value, field));

                    row.SetValue(STATESTREET_Fields.PERC_WITHOUT_LT.ToString(), field.Value);
                    row.SetValue(STATESTREET_Fields.PERC_WITH_LT.ToString(), field.Value);
                }

            }
            return result;
        }

        static string Domain(int position, DomainKind domainKind, AggregateValue field) {

            if (position == 1) {
                switch (domainKind) {
                    case DomainKind.Code:
                        return AggregateStaticData.DOMAIN1_CODE;
                    case DomainKind.Value:
                        if (field.Category == AggregateValueCategory.Valuta) return AggregateStaticData.DOMAIN1_VALUE_VALUTA;
                        if (field.AssetClass == CovipConstants.TITOLO_DI_DEBITO) return AggregateStaticData.DOMAIN1_VALUE_TDD;
                        if (field.AssetClass == CovipConstants.TITOLO_DI_CAPITALE) return AggregateStaticData.DOMAIN1_VALUE_TDC;
                        throw new Exception($"Cannot decode domain 1 with asseClass: {field.AssetClass} and category: {field.Category}");
                }
                return null;
            }

            switch (field.Category) {

                case AggregateValueCategory.AreaGeografica:
                    if (position == 2) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_AREA_GEOGRAFICA;
                            case DomainKind.Value:
                                return field.Area;
                            case DomainKind.Description:
                                return AggregateStaticData.AREA_DES[field.Area];
                        }
                    }
                    break;

                case AggregateValueCategory.Emittete_Rating:
                    if (position == 2) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_EMITTENTE;
                            case DomainKind.Value:
                                return field.Emittente;
                            case DomainKind.Description:
                                return AggregateStaticData.EMITTENTE_DES[field.Emittente];
                        }
                    }
                    if (position == 3) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_RATING;
                            case DomainKind.Value:
                                return field.Rating;
                            case DomainKind.Description:
                                return AggregateStaticData.RATING_DES[field.Rating];
                        }
                    }
                    break;

                case AggregateValueCategory.Emittente_Duration:
                    if (position == 2) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_EMITTENTE;
                            case DomainKind.Value:
                                return field.Emittente;
                            case DomainKind.Description:
                                return AggregateStaticData.EMITTENTE_DES[field.Emittente];
                        }
                    }
                    if (position == 3) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_DURATION;
                            case DomainKind.Value:
                                return field.Duration;
                            case DomainKind.Description:
                                return AggregateStaticData.DURATION_DES[field.Duration];
                        }
                    }
                    break;

                case AggregateValueCategory.SettoreAttivitaEconomica:
                    if (position == 2) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_SETTORE_ATTIVITA_ECONOMICA;
                            case DomainKind.Value:
                                return field.Settore;
                            case DomainKind.Description:
                                return AggregateStaticData.SETTORE_ATTIVITA_ECONOMICA_DES[field.Settore];
                        }
                    }
                    break;

                case AggregateValueCategory.Valuta:
                    if (position == 2) {
                        switch (domainKind) {
                            case DomainKind.Code:
                                return AggregateStaticData.CODE_VALUTA;
                            case DomainKind.Value:
                                return field.Valuta;
                        }
                    }
                    break;

                default:
                    break;
            }
            return null;
        }
    }
}
