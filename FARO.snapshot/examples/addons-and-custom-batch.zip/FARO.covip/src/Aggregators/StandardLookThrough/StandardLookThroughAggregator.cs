using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;
using static FARO.Covip.Aggregators.Engine.StandardLTImageFieldNames;
using Microsoft.EntityFrameworkCore;
using FARO.Covip.DataLayer.EF.Model;
using FARO.Expression;

namespace FARO.Covip.Aggregators.Engine {
    public class StandardLookThroughAggregator : AbstractCovipAggregatorEngine {
        public StandardLookThroughAggregator(string connectionString, CovipAggregatorConfig config) : base(connectionString, config) { }

        public override IImageOutput Aggregate(IAggregator aggregator, IImageOutput output, string dataRootPath) {
            output = GroupByISINAndType(output, out var isinCodes);
            AppendCurrencies(dataRootPath, output, isinCodes);
            return OnAggregate(aggregator, output, dataRootPath);
        }

        public override IEnumerable<FieldDescription> GetFields(AggregatorDefinition aggregatorDefinition) => Enum.GetNames(typeof(StandardLTImageFieldNames)).Select(FieldDescription.Create);

        public override IEnumerable<string> GetAggregatedFields(AggregatorDefinition aggregatorDefinition) => null;

        protected virtual IImageOutput OnAggregate(IAggregator aggregator, IImageOutput output, string dataRootPath) => output;

        ImageOutput GroupByISINAndType(IImageOutput output, out Dictionary<string, ImageOutputRow> uniqueIsinCodes) {
            var ret = new ImageOutput();
            var isinCodes = new Dictionary<string, ImageOutputRow>();
            var grouped = new Dictionary<string, List<ImageOutputRow>>();

            static string Hash(ImageOutputRow r) => $"{r.GetValueExact(CODICE_ISIN_OICR.ToString())}" + "§" +
                                                    $"{r.GetValueExact(COD_ISIN_COMPONENTE_NELL_OICR.ToString())}" + "§" +
                                                    $"{r.GetValueExact(DESCRIZIONE_COMPONENTE_NELL_OICR.ToString())}" + "§" +
                                                    $"{r.GetValueExact(ASSET_CLASS_COMPONENTE_NELL_OICR.ToString())}" + "§" +
                                                    $"{r.GetValueExact(DIVISA_COMPONENTE_NELL_OICR.ToString())}";

            output.IterateRows(row => {
                if (ExpressionEvaluator.EvalCondition(Config.Filter, row)) {
                    // create list of unique isin codes (to fullfill out param)
                    var isinCode = row.GetValueExact(CODICE_ISIN_OICR.ToString()) as string;
                    if (!isinCodes.ContainsKey(isinCode)) isinCodes.Add(isinCode, row);
                    var hashKey = Hash(row);
                    if (!grouped.ContainsKey(hashKey)) grouped.Add(hashKey, new List<ImageOutputRow>());
                    grouped[hashKey].Add(row);
                }
            });

            foreach (var group in grouped) {
                if (group.Value.Count == 1) {
                    ret.AddRow(group.Value.Single());
                    continue;
                }
                var rowToAdd = group.Value.First();
                var navTot = group.Value.Sum(r => (double)GetSafeDoubleValue(r.GetDynamicValue(CONTROVALORE_NAV_COMPONENTE_OICR.ToString())));
                var espTot = group.Value.Sum(r => (double)GetSafeDoubleValue(r.GetDynamicValue(CONTROVALORE_ESPOSIZIONE_COMPONENTE_OICR.ToString())));
                rowToAdd.SetValue(CONTROVALORE_NAV_COMPONENTE_OICR.ToString(), navTot);
                rowToAdd.SetValue(CONTROVALORE_ESPOSIZIONE_COMPONENTE_OICR.ToString(), espTot);
                ret.AddRow(rowToAdd);
            }

            uniqueIsinCodes = isinCodes;
            return ret;
        }

        static double GetSafeDoubleValue(object value) {
            if (value is double @double) return @double;
            if (value is string @string && string.IsNullOrEmpty(@string.Trim())) value = null;
            return double.Parse($"{value ?? 0}", System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture);
        }

        void AppendCurrencies(string dataRootPath, IImageOutput output, Dictionary<string, ImageOutputRow> isinCodes) {
            var file = Path.Combine(dataRootPath ?? string.Empty, Config.CurrenciesFilePath);
            if (string.IsNullOrEmpty(file.Trim())) return;
            if (!File.Exists(file)) throw new FileNotFoundException(file);

            var cp = new CurrencyProvider();
            cp.LoadText(file);

            if (isinCodes.Any()) {
                var diviseCodes = new Dictionary<string, string>();
                // prefill fixed values UIC codes
                var optsBuilder = new DbContextOptionsBuilder<CovipDBContext>().UseSqlServer(ConnectionString);
                using (var dc = new CovipDBContext(optsBuilder.Options)) {
                    diviseCodes = (from f in dc.FieldValue
                                   where f.FieldSummary.IsFixed &&
                                         !f.FieldSummary.IsPortfolio &&
                                         f.FieldSummary.Name == CovipConstants.DIVISA_COMPONENTE_NELL_OICR &&
                                         f.Provider == CovipConstants.STANDARD_PROVIDER_NAME
                                   select f).ToDictionary(k => k.Target, v => v.Value);
                }

                foreach (var isin in isinCodes) {
                    var cr = cp.GetByIsin(isin.Key);
                    if (isin.Value.GetValueExactAs<bool>(PrefixHelper.KeyName(EXTERNAL_DATA))) continue;

                    var espNeeded = isin.Value.GetValueExactAs<string>(COPERTURA_ESPOSIZIONE_VALUTARIA_OICR.ToString())
                                    == CovipConstants.OICR_CON_ESPOSIZIONE_VALUTARIA;
                    var currencies = cr?.CurrencyValuesExceptEuro;
                    if (espNeeded) {
                        if (!(currencies?.Any() ?? false)) throw new Exception($"{isin.Key} missing in currencies file!");
                        if (currencies != null) {
                            foreach (var cv in currencies) {
                                var divisaUIC = diviseCodes.ContainsKey(cv.ISOCode) ? diviseCodes[cv.ISOCode] : cv.ISOCode;
                                // add currency row values to result image
                                var rowToAdd = new ImageOutputRow(isin.Value);
                                rowToAdd.SetValue(CONTROVALORE_NAV_COMPONENTE_OICR.ToString(), null);
                                rowToAdd.SetValue(DESCRIZIONE_COMPONENTE_NELL_OICR.ToString(), null);
                                rowToAdd.SetValue(ASSET_CLASS_COMPONENTE_NELL_OICR.ToString(), CovipConstants.ASSET_CLASS_COMPONENTE_NELL_OICR_ESPOSIZIONE_VALUTARIA);
                                rowToAdd.SetValue(DIVISA_COMPONENTE_NELL_OICR.ToString(), divisaUIC);
                                rowToAdd.SetValue(CONTROVALORE_ESPOSIZIONE_COMPONENTE_OICR.ToString(), cv.Value);
                                output.AddRow(rowToAdd);
                            }
                        }
                    }
                }
            }
        }
    }
}
