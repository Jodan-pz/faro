
namespace FARO.Covip.Aggregators.Engine {
    public class AggregatedLookThroughRow {
        public string ReferenceDate { get; set; }
        public string AreaGeografica { get; internal set; }
        public string AssetClass { get; internal set; }
        public string CategoriaEmittente { get; internal set; }
        public string FasciaDuration { get; internal set; }
        public string ValutaUIC { get; internal set; }
        public string Rating { get; internal set; }
        public string SettoreAttivitaEconomica { get; internal set; }
        public double? ControvaloreNAV { get; internal set; }
        public double? ControvaloreEsposizione { get; internal set; }
    }
}