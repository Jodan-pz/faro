using System;
using System.Collections.Generic;
using System.Linq;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;

namespace FARO.Covip.Aggregators.Engine {
    internal class StandardPanindAggregator : AbstractCovipAggregatorEngine {
        public StandardPanindAggregator(string connectionString, CovipAggregatorConfig config) : base(connectionString, config) { }

        public override IImageOutput Aggregate(IAggregator aggregator, IImageOutput output, string dataRootPath) {
            var ret = new ImageOutput();
            var groups = new Dictionary<string, List<ImageOutputRow>>();
            output.IterateRows(row => {
                if (row.GetValueExact(StandardPanindImageFieldNames.ISIN.ToString()) is string isinValue && !string.IsNullOrEmpty(isinValue.Trim())) {
                    var grpKey = $"COMPARTO_{row.GetValueExact(StandardPanindImageFieldNames.COVIP_CODICE_COMPARTO.ToString())}_INDEX_{row.GetValueExact(StandardPanindImageFieldNames.INDEX_ID.ToString())}";
                    if (!groups.ContainsKey(grpKey)) groups.Add(grpKey, new List<ImageOutputRow>());
                    groups[grpKey].Add(row);
                }
            });

            foreach (var grp in groups) {
                var tot = grp.Value.Sum(row => row.GetValueExactAs<double>(StandardPanindImageFieldNames.PESO.ToString()));
                double totRebased = 0;
                if (tot == 0) continue;
                ImageOutputRow rowWithMaxWeight = null;
                foreach (var itemGroup in grp.Value) {
                    var weight = itemGroup.GetValueExactAs<double?>(StandardPanindImageFieldNames.PESO.ToString()) ?? 0;
                    var rebased = Math.Round((weight / tot) * 100, 9);
                    itemGroup.SetValue(StandardPanindImageFieldNames.PESO.ToString(), rebased);
                    ret.AddRow(itemGroup);
                    if (rowWithMaxWeight == null || weight > rowWithMaxWeight.GetValueExactAs<double>(StandardPanindImageFieldNames.PESO.ToString())) {
                        rowWithMaxWeight = itemGroup;
                    }
                    totRebased += rebased;
                }
                // apply gap to max value
                if (rowWithMaxWeight != null) {
                    var maxWeightWihGapValue = rowWithMaxWeight.GetValueExactAs<double>(StandardPanindImageFieldNames.PESO.ToString()) + (100 - totRebased);
                    rowWithMaxWeight.SetValue(StandardPanindImageFieldNames.PESO.ToString(), maxWeightWihGapValue);
                }
            }
            return ret;
        }

        public override IEnumerable<FieldDescription> GetFields(AggregatorDefinition aggregatorDefinition) => Enum.GetNames(typeof(StandardPanindImageFieldNames)).Select(FieldDescription.Create);
        public override IEnumerable<string> GetAggregatedFields(AggregatorDefinition aggregatorDefinition) => null;
    }
}
