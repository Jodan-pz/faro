namespace FARO.Covip.Aggregators.Engine {
    public enum StandardPanindImageFieldNames {
        ISIN,
        INDEX_ID,
        COVIP_CODICE_COMPARTO,
        PESO
    }
}