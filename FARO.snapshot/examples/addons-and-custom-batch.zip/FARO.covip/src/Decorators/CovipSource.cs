using System.Collections.Generic;
using FARO.CommonDefinition;
using FARO.CommonDefinition.Domain;

namespace FARO.Covip.Decorators.Engine {
    public class CovipSource : IDecoratorSource {
        const string ARG_CONNECTION = "connection";
        public string Connection { get; set; }

        readonly Argument[] _arguments = { new Argument { Name = ARG_CONNECTION, Description = "Connection name" } };

        public IEnumerable<Argument> Arguments => _arguments;

        public static CovipSource CreateFromDefinition(SourceDefinition source) {
            return new CovipSource
            {
                Connection = source.Arguments[ARG_CONNECTION]
            };
        }
    }
}