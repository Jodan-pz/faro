﻿using System;
using System.Linq;
using System.Collections.Generic;
using FARO.Covip.DataLayer.EF.Model;
using FARO.CommonDefinition;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using static FARO.Expression.ExpressionEvaluator;

namespace FARO.Covip.Decorators.Engine {
    public class CovipDecoratorEngine : IDecoratorEngine {
        const string ARG_PROVIDER = "provider";
        const string ARG_FIELD_NAME = "field";
        const string ARG_TARGET = "target";
        const string ARG_DO_NOT_CREATE_VALUE = "donotcreatevalue";
        readonly IConnectionRetriever _connectionRetriever;

        public CovipDecoratorEngine(IConnectionRetriever connectionRetriever) {
            _connectionRetriever = connectionRetriever ?? throw new ArgumentNullException(nameof(connectionRetriever));
        }

        public async Task<IDictionary<string, object>> GetValuesAsync(IDecorator decorator, ImageOutputRow imageOutputRow, string dataRootPath) {
            var ret = new Dictionary<string, object>();
            var source = CovipSource.CreateFromDefinition(decorator.Definition.Source);
            var cs = _connectionRetriever.GetConnectionString(source.Connection) ?? throw new NullReferenceException("Connection not found!");
            var optsBuilder = new DbContextOptionsBuilder<CovipDBContext>().UseSqlServer(cs);
            FieldValue fv = null;
            var fieldName = imageOutputRow.GetValue(decorator.Arguments.Single(a => a.Name == ARG_FIELD_NAME).Value)?.ToString();
            var provider = imageOutputRow.GetValue(decorator.Arguments.Single(a => a.Name == ARG_PROVIDER).Value)?.ToString();
            var target = imageOutputRow.GetValue(decorator.Arguments.Single(a => a.Name == ARG_TARGET).Value)?.ToString();
            var doNotCreateValueCondition = decorator.Arguments.SingleOrDefault(a => a.Name == ARG_DO_NOT_CREATE_VALUE)?.Value;
            var createWhenMissing = true;
            if (!IsNullOrEmpty(doNotCreateValueCondition)) {
                createWhenMissing = !EvalCondition(doNotCreateValueCondition.ToString(), imageOutputRow);
            }

            if (fieldName != null && provider != null && target != null) {
                using var dc = new CovipDBContext(optsBuilder.Options);
                fv = await (from f in dc.FieldValue
                            where f.FieldSummary.Name == fieldName
                               && f.Provider == provider
                               && f.Target == target
                            select f).SingleOrDefaultAsync();

                if (fv == null && createWhenMissing) {
                    var fs = await (from f in dc.FieldSummary
                                    where f.Name == fieldName
                                    select f).SingleOrDefaultAsync() ?? throw new NullReferenceException($"Cannot find field with name {fieldName}");

                    // create field with null value
                    fv = new FieldValue
                    {
                        FieldSummary = fs,
                        HasValue = false,
                        Provider = provider,
                        Target = target,
                        Value = null
                    };
                    await dc.AddAsync(fv);
                    try {
                        await dc.SaveChangesAsync();
                    } catch { /* ignore concurrency erros */}
                }
            }
            return new Dictionary<string, object> { { decorator.Definition.Fields.FirstOrDefault()?.Name ?? "result", fv?.Value } };
        }
    }
}
