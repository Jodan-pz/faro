## FARO.COVIP_BATCH Application Documentation

This is the FARO.COVIP_BATCH Application documentation.