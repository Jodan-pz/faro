using DHARMA.Extensions.DependencyInjection;
using FARO.Batch.Extensions.DependecyInjection;
using FARO.CommonDefinition;
using FARO.Covip;
using FARO.Covip.Services;
using FARO.COVIP_BATCH.CommonDefinition;
using FARO.COVIP_BATCH.Services;
using Lamar;
using Microsoft.Extensions.DependencyInjection;

namespace FARO.COVIP_BATCH.Extensions.DependecyInjection {
    /// <summary>
    /// Lamar DI services setup
    /// </summary>
    public static class RootComposition {
        public static IServiceCollection AddFAROCovipBatch(this ServiceRegistry registry, CacheEngineConfig cacheEngineConfig) {
            registry.ConfigureWithDave<ICOVIP_BATCHAppSupport, COVIP_BATCHAppSupport>((sp, cfg) => {
                cfg.Parameters.WithCache
                    .MapSection("VALIDATION_ERROR_FIELDS_MAPPING")
                    .ToProperty("ValidationErrorFieldsMap");
            });
            registry.AddFARO(cacheEngineConfig);
            registry.AddSingleton<IOutputPortfolio, OutputPortfolioDataService>();
            registry.AddSingleton<ICOVIP_BATCHArgs, COVIP_BATCHArgs>();
            registry.AddSingleton<ICOVIP_BATCHApp, COVIP_BATCHApp>();
            return registry;
        }
    }
}
