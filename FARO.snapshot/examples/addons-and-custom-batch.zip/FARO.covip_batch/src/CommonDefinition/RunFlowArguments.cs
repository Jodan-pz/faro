using System;

namespace FARO.COVIP_BATCH.CommonDefinition {
    public struct RunFlowArguments {
        public string FlowName { get; set; }
        public FlowType FlowType { get; set; }
        public string OutFolder { get; set; }
        public string OutputExtension { get; set; }
        public DateTime RefDate { get; set; }
        public bool SingleFund { get; set; }
        public int? Skip { get; set; }
        public int? Take { get; set; }
        public string FileTransferName { get; set; }
        public string LtoicrPath { get; set; }
        public string LtoicrSearchPath { get; set; }
        public string[] Filter { get; set; }
        public bool ValidateOnly { get; set; }
    }
}
