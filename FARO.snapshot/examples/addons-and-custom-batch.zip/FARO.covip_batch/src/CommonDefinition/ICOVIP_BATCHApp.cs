namespace FARO.COVIP_BATCH.CommonDefinition {
    public interface ICOVIP_BATCHApp {
        void Start(params object[] arguments);
    }
}