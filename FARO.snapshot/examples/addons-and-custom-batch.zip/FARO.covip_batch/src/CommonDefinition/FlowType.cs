namespace FARO.COVIP_BATCH.CommonDefinition {
    public enum FlowType { Anatit, Ltoicr, Anader, Valder, Panind }
}