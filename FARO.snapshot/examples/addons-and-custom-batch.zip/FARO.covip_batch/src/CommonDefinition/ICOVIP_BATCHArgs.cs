namespace FARO.COVIP_BATCH.CommonDefinition {
    public interface ICOVIP_BATCHArgs {
        RunFlowArguments Build();
    }
}