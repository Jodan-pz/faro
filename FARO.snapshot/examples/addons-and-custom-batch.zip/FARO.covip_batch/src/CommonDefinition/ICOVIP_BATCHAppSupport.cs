using System.Collections.Generic;

namespace FARO.COVIP_BATCH.CommonDefinition {
    public interface ICOVIP_BATCHAppSupport {
        Dictionary<string, string> ValidationErrorFieldsMap { get; set; }
    }
}