using Microsoft.Extensions.Logging;
using FARO.COVIP_BATCH.CommonDefinition;
using System;
using System.Collections.Generic;
using System.IO;
using FARO.CommonDefinition;
using System.Linq;
using FARO.CommonDefinition.Exceptions;
using FARO.Covip;
using static FARO.CommonDefinition.ValidatorMessageDefaultContext;

namespace FARO.COVIP_BATCH.Services {
    public class COVIP_BATCHApp : ICOVIP_BATCHApp {
        readonly ICOVIP_BATCHArgs _covipArguments;
        readonly IFlowConfigurationBuilder _flowConfigurationBuilder;
        readonly IFlowRunner _flowRunner;
        readonly IOutputPortfolio _outputPortfolio;
        readonly ICOVIP_BATCHAppSupport _covipAppSupport;
        readonly ILogger<COVIP_BATCHApp> _log;

        public COVIP_BATCHApp(ICOVIP_BATCHArgs covipArguments,
                              ICOVIP_BATCHAppSupport covipAppSupport,
                              IFlowConfigurationBuilder flowConfigurationBuilder,
                              IFlowRunner flowRunner,
                              IOutputPortfolio outputPortfolio,
                              ILogger<COVIP_BATCHApp> log = null) {
            _covipArguments = covipArguments ?? throw new ArgumentNullException(nameof(covipArguments));
            _covipAppSupport = covipAppSupport ?? throw new ArgumentNullException(nameof(covipAppSupport));
            _flowConfigurationBuilder = flowConfigurationBuilder ?? throw new ArgumentNullException(nameof(flowConfigurationBuilder));
            _flowRunner = flowRunner ?? throw new ArgumentNullException(nameof(flowRunner));
            _outputPortfolio = outputPortfolio ?? throw new ArgumentNullException(nameof(outputPortfolio));
            _log = log;
        }

        public void Start(params object[] arguments) => RunFlow(_covipArguments.Build());

        /// <summary>
        /// Run flow
        /// </summary>
        /// <param name="args">Run Arguments</param>
        void RunFlow(RunFlowArguments args) {
            var cfg = _flowConfigurationBuilder.Build(flowName: args.FlowName);
            if (cfg.IsEmpty) throw new Exception($"Cannot build flow '{args.FlowName}'!");

            var filePath = args.OutFolder;
            IDictionary<string, object> stdImageArgs = new Dictionary<string, object> { { "refDate", args.RefDate.ToString("yyyy-MM-dd") }, { "portfolioCode", null } };
            IDictionary<string, object> sfImageArgs = new Dictionary<string, object> { { "refDate", args.RefDate.ToString("yyyy-MM-dd") }, { "isinCode", null } };
            IDictionary<string, object> writerArgs = new Dictionary<string, object> { { "file", null } };

            switch (args.FlowType) {
                case FlowType.Anatit:
                    filePath = Path.Combine(filePath, "ANATIT_");
                    break;
                case FlowType.Ltoicr:
                    filePath = Path.Combine(filePath, "LTOICR_");
                    if (!args.SingleFund) {
                        stdImageArgs = new Dictionary<string, object> {
                            { "refDate", args.RefDate.ToString("yyyy-MM-dd") },
                            { "internalCode", null },
                            { "path", args.LtoicrPath } ,
                            { "searchPath", args.LtoicrSearchPath } };
                    }
                    break;
                case FlowType.Anader:
                    filePath = Path.Combine(filePath, "ANADER_");
                    break;
                case FlowType.Valder:
                    filePath = Path.Combine(filePath, "VALDER_");
                    break;
                case FlowType.Panind:
                    filePath = Path.Combine(filePath, "PANIND_");
                    break;
            }

            var codes = _outputPortfolio.GetCodes(args.SingleFund, args.FileTransferName, args.Filter).Skip(args.Skip ?? 0);
            if (args.Take != null) codes = codes.Take(args.Take.Value);
            var imageArgs = !args.SingleFund ? stdImageArgs : sfImageArgs;

            var cnt = 0;
            var errs = 0;
            foreach (var code in codes) {
                var fileOut = $"{filePath}{code}_{args.RefDate:yyyyMMdd}.{args.OutputExtension}";
                var errorFile = $"{filePath}{code}_{args.RefDate:yyyyMMdd}.errors.txt";
                if (File.Exists(errorFile)) File.Delete(errorFile);

                if (!args.SingleFund) {
                    if (args.FlowType == FlowType.Ltoicr || args.FlowType == FlowType.Valder)
                        imageArgs["internalCode"] = code;
                    else
                        imageArgs["portfolioCode"] = code;
                } else {
                    imageArgs["isinCode"] = code;
                }

                writerArgs["file"] = fileOut;
                _log?.LogInformation("CODE: {0} - #{1} of {2}", code, ++cnt, codes.Count());
                try {
                    cfg.WithArguments(imageArgs, writerArgs)
                       .SingleItem((flow, iArgs, wArgs) => {
                           if (args.ValidateOnly) flow.Writer = null;
                           _flowRunner.Run(flow, iArgs, wArgs);
                       });
                } catch (AggregateException ae) {
                    ae.Handle((inner) => {
                        errs++;
                        _log?.LogError("Error: " + inner.Message);
                        ErrorFileRow.AppendExceptionToFile(errorFile, inner, args, code);
                        return true;
                    });
                } catch (ValidateResultException vre) {
                    using var errFile = File.CreateText(errorFile);
                    errs++;
                    errFile.WriteLine(ErrorFileRow.GetHeader());
                    foreach (var validator in vre.Result) {
                        if (validator.Context != GENERIC_ERROR_RAW_VALUES) {
                            errFile.WriteLine(ErrorFileRow.GetErrorRowByFlow(code, validator, args, _covipAppSupport.ValidationErrorFieldsMap).ToDelimitedString());
                        }
                        _log?.LogError("[{0}] Rule: {1} - {2}", code, validator.Key, validator.Message);
                    }

                } catch (Exception ex) {
                    errs++;
                    _log?.LogError("[{0}] Exception: {1}", code, ex.Message);
                    ErrorFileRow.AppendExceptionToFile(errorFile, ex, args, code);
                }
            }
            if (errs != 0) throw new ApplicationException("Run completed with errors.");
        }
    }
}
