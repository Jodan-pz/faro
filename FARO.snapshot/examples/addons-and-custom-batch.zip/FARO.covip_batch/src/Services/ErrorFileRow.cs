using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using FARO.CommonDefinition;
using FARO.COVIP_BATCH.CommonDefinition;
using static FARO.COVIP_BATCH.Services.ErrorFileRow.Fields;

namespace FARO.COVIP_BATCH.Services {

    internal class ErrorFileRow {
        public enum Fields {
            TIME_STAMP,
            PORTFOLIO_CODE,
            REFERENCE_DATE,
            COMPANY_CODE,
            PROVIDER_NAME,
            SINGLE_FUND,
            CONTEXT,
            TYPE,
            ISIN_CODE,
            ISIN_CODE_LT,
            MESSAGE,
            FATAL
        }

        #region Props
        readonly Dictionary<Fields, string> _values = new Dictionary<Fields, string>();
        public string GetValue(Fields field) => _values[field];
        public string SetValue(Fields field, string value) => _values[field] = value;

        #endregion

        public ErrorFileRow() {
            SetValue(TIME_STAMP, DateTime.Now.ToString("HH:mm:ss"));
        }

        public static string GetHeader() {
            var sb = new StringBuilder();
            foreach (var h in Enum.GetNames(typeof(Fields))) sb.Append($"{h}\t");
            var ret = sb.ToString();
            return ret[0..^1];
        }

        public static void AppendExceptionToFile(string file, Exception ex, RunFlowArguments args, string code) {
            if (!File.Exists(file)) File.WriteAllLines(file, new string[] { GetHeader() });
            var errorException = new ErrorFileRow();
            errorException.SetValue(COMPANY_CODE, "AMUNDI");
            errorException.SetValue(PROVIDER_NAME, "STANDARD");
            errorException.SetValue(SINGLE_FUND, args.SingleFund ? "YES" : "NO");
            errorException.SetValue(TYPE, "Exception");
            errorException.SetValue(FATAL, true.ToString());
            errorException.SetValue(REFERENCE_DATE, args.RefDate.ToString("yyyy-MM-dd"));
            errorException.SetValue(PORTFOLIO_CODE, code);
            errorException.SetValue(MESSAGE, "\"" + (ex.Message ?? string.Empty).Replace(Environment.NewLine, string.Empty) + "\"");
            File.AppendAllLines(file, new string[] { errorException.ToDelimitedString() });
        }

        public static ErrorFileRow GetErrorRowByFlow(string code, ValidatorMessage validator, RunFlowArguments args, IDictionary<string, string> errorFieldsMap) {
            var row = validator.Row;
            var ret = new ErrorFileRow();
            ret.SetValue(COMPANY_CODE, "AMUNDI");
            ret.SetValue(PROVIDER_NAME, "STANDARD");
            ret.SetValue(SINGLE_FUND, args.SingleFund ? "YES" : "NO");
            ret.SetValue(CONTEXT, validator.Context != null ? string.Join(",", validator.Context) : null);
            ret.SetValue(TYPE, "Default");
            ret.SetValue(MESSAGE, "\"" + (validator.Message ?? string.Empty).Replace(Environment.NewLine, string.Empty) + "\"");
            ret.SetValue(FATAL, true.ToString());
            ret.SetValue(REFERENCE_DATE, args.RefDate.ToString("yyyy-MM-dd"));
            ret.SetValue(PORTFOLIO_CODE, code);

            var isinCodeMapKey = $@"{args.FlowType.ToString().ToUpper()}\ISIN_CODE";
            var isinCodeLTMapKey = $@"{args.FlowType.ToString().ToUpper()}\ISIN_CODE_LT";
            try {

                var isinCode = errorFieldsMap?.ContainsKey(isinCodeMapKey) ?? false ? errorFieldsMap[isinCodeMapKey] : null;
                if (isinCode == null) throw new Exception($"{isinCodeMapKey} parameter configuration cannot be null or missing.");
                if (!row.ContainsName(isinCode)) throw new Exception($"{isinCode} missing in image row.");

                var isinCodeLT = errorFieldsMap?.ContainsKey(isinCodeLTMapKey) ?? false ? errorFieldsMap[isinCodeLTMapKey] : null;
                if (isinCodeLT == null) throw new Exception($"{isinCodeLTMapKey} parameter configuration cannot be null or missing.");
                if (!row.ContainsName(isinCodeLT)) throw new Exception($"{isinCodeLT} missing in image row.");

                ret.SetValue(ISIN_CODE, row.GetValueExactAs<string>(isinCode));
                ret.SetValue(ISIN_CODE_LT, row.GetValueExactAs<string>(isinCodeLT));
            } catch (Exception ex) {
                ret.SetValue(MESSAGE, ex.Message);
            }
            return ret;
        }

        public string ToDelimitedString() {
            var sb = new StringBuilder();
            foreach (var val in Enum.GetValues(typeof(Fields))) {
                sb.AppendFormat("{0}\t", _values.ContainsKey((Fields)val) ? _values[(Fields)val] : null);
            }
            var ret = sb.ToString();
            return ret[0..^1];
        }
    }
}
