using System;
using System.Linq;
using DHARMA.BaseClasses;
using FARO.COVIP_BATCH.CommonDefinition;

namespace FARO.COVIP_BATCH.Services {
    public class COVIP_BATCHArgs : ICOVIP_BATCHArgs {
        readonly IDave _dave;

        public COVIP_BATCHArgs(IDave dave) {
            _dave = dave ?? throw new ArgumentNullException(nameof(dave));
        }

        public RunFlowArguments Build() {
            var flowName = _dave.GetArgValue<string>("FLOW_NAME");
            var flowType = GetFlowType(_dave.GetArgValue<string>("FLOW_TYPE"));
            var refDate = _dave.GetArgValue<DateTime>("DATE");
            var singleFund = _dave.GetArgValue<bool?>("SINGLEFUND") ?? false;
            var outFolder = _dave.GetArgValue<string>("OUTFOLDER");
            var outputExtension = _dave.GetArgValue<string>("OUTPUT_EXTENSION") ?? "txt";
            var ltoicrPath = _dave.GetArgValue<string>("LTOICR_PATH");
            var ltoicrSearchPath = _dave.GetArgValue<string>("LTOICR_SEARCHPATH");
            var fileTransferName = _dave.GetArgValue<string>("FILETRANSFER_NAME");
            var skip = _dave.GetArgValue<int?>("SKIP");
            var take = _dave.GetArgValue<int?>("TAKE");
            var filter = (_dave.GetArgValue<string>("FILTER") ?? string.Empty).Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
            if (filter.Length == 0) filter = null;
            var validateOnly = _dave.GetArgValue<bool?>("VALIDATE_ONLY") ?? false;

            return new RunFlowArguments
            {
                FlowName = flowName,
                FlowType = flowType,
                OutFolder = outFolder,
                OutputExtension = outputExtension,
                RefDate = refDate,
                SingleFund = singleFund,
                Skip = skip,
                Take = take,
                FileTransferName = fileTransferName,
                LtoicrPath = ltoicrPath,
                LtoicrSearchPath = ltoicrSearchPath,
                Filter = filter,
                ValidateOnly = validateOnly
            };
        }

        FlowType GetFlowType(string flow) {
            return (flow.ToLower()) switch
            {
                "anatit" => FlowType.Anatit,
                "ltoicr" => FlowType.Ltoicr,
                "anader" => FlowType.Anader,
                "valder" => FlowType.Valder,
                "panind" => FlowType.Panind,
                _ => throw new ApplicationException($"Flow type not managed: '{flow}'"),
            };
        }
    }
}
