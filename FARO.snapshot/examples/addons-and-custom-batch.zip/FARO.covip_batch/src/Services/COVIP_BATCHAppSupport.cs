using System.Collections.Generic;
using FARO.COVIP_BATCH.CommonDefinition;

namespace FARO.COVIP_BATCH.Services {
    public class COVIP_BATCHAppSupport : ICOVIP_BATCHAppSupport {
        public Dictionary<string, string> ValidationErrorFieldsMap { get; set; }
    }
}